# EXCERCISE 2 README

The App.js acts as a main file for this project. Click [here](https://imgur.com/a/tlgpyfD) to see an image on how to import. Simply click the 3 vertical dots to the top right of the projects files, and then import via github or via individual files. From there, a preview of the project should appear on the right, or on your device if it is setup properly. This project also contains 6 images that can be found in the "assest" folder.
